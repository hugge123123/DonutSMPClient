# DonutSMP Client — Minecraft 1.21.11

A Fabric client-side starter project featuring an original dark click GUI.

## Features in this starter
- Right Shift opens the menu; Escape closes it.
- Dark panel UI with purple accents.
- Category navigation and searchable module cards.
- Click cards to toggle their UI state.
- Targets Minecraft Java Edition 1.21.11 and Java 21.

## Important
This is a starter mod project, not a finished PvP client. The included module toggles demonstrate the menu system; they do not implement combat cheats or server-specific automation. Add legitimate client-side features in each module's activation/deactivation lifecycle.

## Build
1. Install JDK 21.
2. Install a recent Gradle-compatible IDE such as IntelliJ IDEA.
3. Open this folder as a Gradle project and let Gradle sync.
4. Run `./gradlew build` (Windows: `gradlew.bat build`).
5. Find the mod JAR under `build/libs/`.
6. Install Fabric Loader for Minecraft 1.21.11 and place the JAR in your `.minecraft/mods` folder. Install a matching Fabric API build too.

## Version notes
The project targets Fabric Loader 0.18.1, Fabric API 0.141.6+1.21.11 and Yarn mappings 1.21.11+build.1. If Gradle cannot resolve a mapping artifact, update the Yarn mappings property to a published 1.21.11 build from Fabric Maven.
